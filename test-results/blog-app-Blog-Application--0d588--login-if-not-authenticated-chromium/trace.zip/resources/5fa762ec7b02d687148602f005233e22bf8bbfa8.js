(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__013w1i7._.css","static/chunks/node_modules_1fd1zqc._.js","static/chunks/components_0r7-aln._.js"],
    source: "dynamic"
});
